import BouttonTri from "./bouttonTri";
import BouttonFiltre from "./bouttonFiltre";
import TableauTaches from "./tableauTaches";

function bodyApp()
{
    return(
        <body>
            <section>
                <BouttonTri/>
                <BouttonFiltre/>
            </section>
            <section>
                <TableauTaches/>
            </section>
        </body>
    )
}

export default bodyApp;