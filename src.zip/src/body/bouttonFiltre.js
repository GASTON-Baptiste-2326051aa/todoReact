function bouttonFiltre()
{
    return(
        <div>
            <button className="bouttonFiltre">Filtre</button>
        </div>
    );
}

export default bouttonFiltre;