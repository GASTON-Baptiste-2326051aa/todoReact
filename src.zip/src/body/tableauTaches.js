function tableauTaches() {
    return (
        <div>
        <h1>Tableau des tâches</h1>
        </div>
    );
}

export default tableauTaches;