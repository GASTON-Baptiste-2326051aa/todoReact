function bouttonTri(props) {
    return (
        <button onClick={props.tri}>Tri</button>
    )
}

export default bouttonTri;