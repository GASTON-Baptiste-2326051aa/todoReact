function compteur(){
    return (
        <div>
            <h1>Compteur</h1>
        </div>
    )
}

export default compteur;