import Graphique from "./graphique";
import Compteur from "./compteur";

function headerApp()
{
    return(
        <header>
            <section>
                <Compteur/>
                <h1>To Do</h1>
                <Graphique/>
            </section>
        </header>
    )
}

export default headerApp;