function graphique() {
    return(
        <div>
            <h1>Graphique</h1>
        </div>
    )
}

export default graphique;