import './styles/App.css';
import HeaderApp from "./header/headerApp";
import BodyApp from "./body/bodyApp";
import FooterApp from "./footer/footerApp";

function App() {
  return (
    <html>
      <HeaderApp/>
      <BodyApp/>
      <FooterApp/>
    </html>
  );
}

export default App;