function bouttonAffichageTaches()
{
    return(<button content={"Taches"} ></button>)
}

export default bouttonAffichageTaches();