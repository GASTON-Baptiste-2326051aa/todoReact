import BouttonAffichageTaches from "./bouttonAffichageTaches";
import BouttonAjout from "./bouttonAjout";
import BouttonAffichageCategories from "./bouttonAffichageCategories";

function footerApp()
{
    return(
        <footer>
            <section>
                <BouttonAjout/>
            </section>
            <section>
                <BouttonAffichageTaches/>
                <BouttonAffichageCategories/>
            </section>
        </footer>
    )
}

export default footerApp();