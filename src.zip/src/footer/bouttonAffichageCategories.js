function bouttonAffichageCategories()
{
    return(<button content={"Catégories"} ></button>)
}

export default bouttonAffichageCategories