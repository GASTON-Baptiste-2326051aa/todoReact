function bouttonAjout()
{
    return(<button content={"Add"} ></button>)
}

export default bouttonAjout();